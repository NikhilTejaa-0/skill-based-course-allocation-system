package casestudy;

class Course {
    private String courseId;
    private String courseName;
    private String requiredSkill;
    private int minMarks;

    public Course(String courseId, String courseName, String requiredSkill, int minMarks) {
        this.courseId = courseId;
        this.courseName = courseName;
        this.requiredSkill = requiredSkill;
        this.minMarks = minMarks;
    }

    public String getCourseName() { return courseName; }
    public String getRequiredSkill() { return requiredSkill; }
    public int getMinMarks() { return minMarks; }
}