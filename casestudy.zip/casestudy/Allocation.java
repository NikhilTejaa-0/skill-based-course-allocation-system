package casestudy;

import java.util.*;

abstract class Allocation {
    abstract void allocateCourses(Student s, ArrayList<Course> courses);
}