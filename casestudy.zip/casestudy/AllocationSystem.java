package casestudy;

import java.util.*;

class AllocationSystem extends Allocation {

    @Override
    public void allocateCourses(Student s, ArrayList<Course> courses) {
        System.out.println("\nAllocating courses for " + s.getName() + "...");
        boolean found = false;

        for (Course c : courses) {
            if (isEligible(s, c)) {
                System.out.println("Eligible for: " + c.getCourseName());
                found = true;
            }
        }

        if (!found) {
            System.out.println("No suitable courses found.");
        }
    }

    private boolean isEligible(Student s, Course c) {
        return s.getSkills().contains(c.getRequiredSkill())
                && s.getMarks() >= c.getMinMarks();
    }
}