package casestudy;

import java.util.*;

class Student extends Person {
    private ArrayList<String> skills;
    private int marks;

    public Student(int id, String name, ArrayList<String> skills, int marks) {
        super(id, name);
        this.skills = skills;
        this.marks = marks;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public ArrayList<String> getSkills() { return skills; }
    public int getMarks() { return marks; }

    public void setName(String name) { this.name = name; }
    public void setSkills(ArrayList<String> skills) { this.skills = skills; }
    public void setMarks(int marks) { this.marks = marks; }

    @Override
    public void display() {
        System.out.println("ID: " + id + ", Name: " + name +
                ", Skills: " + skills + ", Marks: " + marks);
    }
}