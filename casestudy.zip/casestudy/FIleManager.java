package casestudy;

import java.io.*;
import java.util.*;

class FileManager {

    public void saveStudents(ArrayList<Student> students) {
        try (FileWriter fw = new FileWriter("students.txt")) {
            for (Student s : students) {
                fw.write(s.getId() + "," + s.getName() + "," +
                        s.getSkills() + "," + s.getMarks() + "\n");
            }
            System.out.println("Students saved to file.");
        } catch (IOException e) {
            System.out.println("Error writing file.");
        }
    }

    public void readStudents() {
        try (BufferedReader br = new BufferedReader(new FileReader("students.txt"))) {
            String line;
            System.out.println("\nReading from file:");
            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            System.out.println("Error reading file.");
        }
    }
}