package casestudy;

import java.util.*;

public class COURSE_ALLOCATION_SYSTEM {

    public static void updateStudent(ArrayList<Student> studentList, Scanner sc) {
        System.out.print("Enter Student ID to update: ");
        int id = sc.nextInt();
        sc.nextLine();

        for (Student s : studentList) {
            if (s.getId() == id) {

                System.out.print("Enter new name: ");
                String name = sc.nextLine();
                s.setName(name);

                System.out.print("Enter number of skills: ");
                int count = sc.nextInt();
                sc.nextLine();

                ArrayList<String> skills = new ArrayList<>();
                for (int i = 0; i < count; i++) {
                    System.out.print("Enter skill " + (i + 1) + ": ");
                    skills.add(sc.nextLine());
                }
                s.setSkills(skills);

                System.out.print("Enter new marks: ");
                int marks = sc.nextInt();
                s.setMarks(marks);

                System.out.println("Student updated successfully!");
                return;
            }
        }

        System.out.println("Student not found.");
    }

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        ArrayList<Student> studentList = new ArrayList<>();
        ArrayList<Course> courses = new ArrayList<>();

        AllocationSystem system = new AllocationSystem();
        FileManager fm = new FileManager();

        int choice;

        do {
            try {
                System.out.println("\n===== MENU =====");
                System.out.println("1. Add Student");
                System.out.println("2. Add Course");
                System.out.println("3. Display Students");
                System.out.println("4. Allocate Courses");
                System.out.println("5. Save to File");
                System.out.println("6. Read from File");
                System.out.println("7. Update Student");
                System.out.println("8. Exit");
                System.out.print("Enter choice: ");

                choice = sc.nextInt();

                switch (choice) {

                    case 1:
                        System.out.print("Enter ID: ");
                        int id = sc.nextInt();
                        sc.nextLine();

                        System.out.print("Enter Name: ");
                        String name = sc.nextLine();

                        System.out.print("Number of skills: ");
                        int skillCount = sc.nextInt();
                        sc.nextLine();

                        ArrayList<String> skills = new ArrayList<>();
                        for (int i = 0; i < skillCount; i++) {
                            System.out.print("Enter skill " + (i + 1) + ": ");
                            skills.add(sc.nextLine());
                        }

                        System.out.print("Enter Marks: ");
                        int marks = sc.nextInt();

                        studentList.add(new Student(id, name, skills, marks));
                        System.out.println("Student added.");
                        break;

                    case 2:
                        System.out.print("Enter Course ID: ");
                        String cid = sc.nextLine();

                        System.out.print("Enter Course Name: ");
                        String cname = sc.nextLine();

                        System.out.print("Required Skill: ");
                        String skill = sc.nextLine();

                        System.out.print("Minimum Marks: ");
                        int minMarks = sc.nextInt();

                        courses.add(new Course(cid, cname, skill, minMarks));
                        System.out.println("Course added.");
                        break;

                    case 3:
                        for (Student s : studentList) {
                            s.display();
                        }
                        break;

                    case 4:
                        for (Student s : studentList) {
                            system.allocateCourses(s, courses);
                        }
                        break;

                    case 5:
                        fm.saveStudents(studentList);
                        break;

                    case 6:
                        fm.readStudents();
                        break;

                    case 7:
                        updateStudent(studentList, sc);
                        break;

                    case 8:
                        System.out.println("Exiting program...");
                        break;

                    default:
                        System.out.println("Invalid choice.");
                }

            } catch (InputMismatchException e) {
                System.out.println("Invalid input! Enter correct type.");
                sc.nextLine();
                choice = 0;
            }

        } while (choice != 8);

        sc.close();
    }
}